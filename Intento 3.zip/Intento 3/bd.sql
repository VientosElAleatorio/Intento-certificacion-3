-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema mision_frecuente
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema mision_frecuente
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `mision_frecuente` DEFAULT CHARACTER SET utf8 ;
USE `mision_frecuente` ;

-- -----------------------------------------------------
-- Table `mision_frecuente`.`usuarios`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mision_frecuente`.`usuarios` (
  `id` INT NOT NULL,
  `nombre` VARCHAR(255) NULL,
  `apellido` VARCHAR(255) NULL,
  `email` VARCHAR(255) NULL,
  `password` VARCHAR(255) NULL,
  `created_at` VARCHAR(255) NULL,
  `updated_at` VARCHAR(255) NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mision_frecuente`.`missions`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mision_frecuente`.`missions` (
  `id` INT NOT NULL,
  `nombre` VARCHAR(255) NULL,
  `fecha` TIME NULL,
  `voluntarios` INT NULL,
  `descripcion` TEXT NULL,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  `usuario_id` INT NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_missions_usuarios_idx` (`usuario_id` ASC) VISIBLE,
  CONSTRAINT `fk_missions_usuarios`
    FOREIGN KEY (`usuario_id`)
    REFERENCES `mision_frecuente`.`usuarios` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
