from flask_app.config.mysqlconnection import connectToMySQL
from flask import flash
from datetime import date
DB = "mision_frecuente"

class Mision:
    def __init__(self, data):
        self.id = data["id"]
        self.nombre = data["nombre"]
        self.fecha = data["fecha"]
        self.voluntarios = data["voluntarios"]
        self.descripcion = data["descripcion"]
        self.created_at = data["created_at"]
        self.updated_at = data["updated_at"]
        self.usuario_id = data["usuario_id"]


    @classmethod
    def save(cls, data):
        query = "INSERT INTO misions (nombre, fecha, voluntarios, descripcion, created_at, updated_at, usuario_id) VALUES (%(nombre)s, %(fecha)s, %(voluntarios)s, %(descripcion)s, NOW(), NOW(), %(usuario_id)s)"
        result = connectToMySQL(DB).query_db(query, data)
        return result
    @classmethod
    def get_by_id(cls, data):
        query = "SELECT * FROM misions LEFT JOIN usuarios ON misions.usuario_id = usuarios.id WHERE misions.id = %(id)s;"
        results = connectToMySQL(DB).query_db(query, data)
        return results[0] if results else None
    @classmethod
    def update(cls, data):
        query = "UPDATE mision_frecuente SET `nombre` = %(nombre)s, `fecha` = %(fecha)s, `voluntarios` = %(voluntarios)s, `descripcion` = %(descripcion)s, `updated_at` = NOW() WHERE id = %(id)s"
        results = connectToMySQL(DB).query_db(query, data)
        return results
    @classmethod
    def get_all(cls):
        query = "SELECT missions.*, usuarios.nombre AS nombre_usuario FROM missions LEFT JOIN usuarios ON missions.usuario_id = usuarios.id"
        misiones = []
        for mision in misiones:
            misiones.append(cls(mision))
        return misiones
    @classmethod
    def delete(cls, data):
        query = "DELETE FROM mision_frecuente WHERE id = %(id)s"
        results = connectToMySQL(DB).query_db(query, data)
        return results

    @staticmethod
    def validate_mission(form):
        is_valid = True
        today = date.today()
        if len(form['descripcion']) < 20:
            flash("El descripcion no puede tener menos de 20 caracteres", "mission")
            is_valid = False

        if form["fecha"] < str(today):
            flash("La fecha no puede ser en el pasado.", "mission")
            is_valid = False

        return is_valid
    