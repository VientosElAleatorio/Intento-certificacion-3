from flask import flash, redirect, render_template, request, session
from flask_app.models.usuario import Usuario
from flask_app.models.mision import Mision
from flask_app import app

@app.route("/nuevo")
def nuevo_mision():
    if "usuario_id" not in session:
        return redirect("/")
    user = Usuario.get_one({"id": session["usuario_id"]})
    if not user:
        return redirect("/")
    return render_template("nueva_mision.html")

@app.route("/agregar_mision", methods=["POST"])
def agregar_mision():
    if not Mision.validate_mission(request.form):
        redirect("/nuevo")
    data = {**request.form, "usuario_id": session["usuario_id"]}
    Mision.save(data)

    return redirect("/dashboard")

@app.route("/ver/<int:id>")

def ver_mision(id):
    if "usuario_id" not in session:
        return redirect("/")
    user = Usuario.get_one({"id": session["usuario_id"]})
    if not user:
        return redirect("/")
    data = {
        "id": id
    }
    mision = Mision.get_by_id(data)
    return render_template("ver_mision.html", mision = mision)
@app.route("/editar/<int:id>")
def editar_mision(id):
    if "usuario_id" not in session:
        return redirect("/")
    user = Usuario.get_one({"id": session["usuario_id"]})
    if not user:
        return redirect("/")
    data = {
        "id": id
    }
    mision = Mision.get_by_id(data)
    return render_template("editar_mision.html", mision = mision)
@app.route("/actualizar_mision", methods = ["POST"])
def actualizar_mision():
    obtener_id = {
        id: request.form['id']
    }
    if not Mision.validate_mission(request.form):
        return redirect(f"/editar/{obtener_id[id]}")
    
    data = { 
        'id':request.formulario['mision_id'],
        'nombre':request.formulario['nombre'],
        'fecha':request.formulario['fecha'],
        'voluntarios':request.formulario['voluntarios'],
        'descripcion':request.formulario['descripcion'],

    }
    Mision.update(data)
    return redirect("/dashboard")

@app.route("/borrar_mision/<int:id>")
def borrar_mision(id):
    data = {
        "id": id
    }
    Mision.delete(data)
    return redirect("/dashboard")