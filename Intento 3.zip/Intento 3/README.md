![https://media1.tenor.com/m/zpmm9vsMGCUAAAAC/spinning-pokemon.gif](https://media1.tenor.com/m/zpmm9vsMGCUAAAAC/spinning-pokemon.gif)

Esto es todo de mi parte, saludos.

- Alguien.